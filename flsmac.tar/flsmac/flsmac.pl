#!/usr/bin/perl
#For support visit http://sourceforge.net/projects/flsmac/

#------------------
#Functions
#------------------

#function to print the interface menu
#takes the FLS command and the mactime command as input
sub mainMenu {
	print "---------------------------------------------------------------------------\n";
	print "Current FLS statement: $_[0] \n";
	print "Current mactime statement: $_[1] \n";
	print "---------------------------------------------------------------------------\n";
	print "Please select an option below:\n";
	print " h : Displays help page\n";
	print " 1 : Filesystem type\n";
	print " 2 : Starting point in filesystem\n";
	print " 3 : Offset\n";
	print " 4 : Date range\n";
	print " 5 : File to output\n";
	print " p : Process commands\ninput-> ";
	chomp($input=<STDIN>);
	return $input;
}

#------------------
#Variable default initialization
#------------------

($fileSysType,$selection,$fileSysType,$offset,$range,$start,$end,$outFile)='';
$startLoc='/ ';

#------------------
#Main Program
#------------------

#if an argument is passed, set it to the file name - else, query user for file name
#if -h argument is passed, display help contents then exit
#else query user for filename
#test if file name exists, if not end program and ask the user to try again
if($ARGV[0]) 
{
	chomp($file=$ARGV[0]);
	if($file =~ m/^-h$/) { system("cat flsmac.info | more"); exit; }
}
else { print "Enter file location and name: "; chomp($file=<STDIN>); }
unless(-e "$file") { print "The file \"$file\" does NOT exist!\nPlease run the program again with a valid file for input.\n"; exit; }

#call function to ouput current command strings
$selection=mainMenu("fls " . $fileSysType . $offset . "-r -m " . $startLoc . $file . " >/tmp/flsmactmp", "mactime -b /tmp/flsmactmp $range" . $outFile);

while($selection)
{
	#if selection is h, display help contents
	if($selection =~ m/[hH]/)
	{
		system("cat flsmac.info | more");
		print "\nPlease press [enter/return] to continue.";
		<STDIN>;
	}
	#if selection is 1, query user for file system type then build command
	elsif($selection eq '1')
	{
		print "Please enter file system type: ";
		chomp($fileSysType=<STDIN>);
		unless($fileSysType eq '') { $fileSysType = "-f $fileSysType "; }
	}
	#if selection is 2, query user where in the file structure they want us to start then build command
	elsif($selection eq '2')
	{
		print "Where would you like us to start? ";
		chomp($startLoc=<STDIN>);
		if($startLoc eq '') { $startLoc='/ '; }
		else{ $startLoc="$startLoc "; }
	}
	#if selection is 3, query user for the starting sector then build the command
	elsif($selection eq '3')
	{
		print "What is the starting sector? ";
		chomp($offset=<STDIN>);
		unless($offset eq '') { $offset = "-o $offset "; }
	}
	#if selection is 4, query user for the start & end dates, then test for valid input format
	elsif($selection eq '4')
	{
		print "What is the starting date (yyyy-mm-dd)? ";
		chomp($start=<STDIN>);
		print "What is the ending date (yyyy-mm-dd)? ";
		chomp($end=<STDIN>);
		$range="$start..$end ";
		unless($range =~ m/^\d{4}\-\d{2}\-\d{2}\.\.\d{4}\-\d{2}\-\d{2}\s$/)
		{
			print "Bad format entered! Please press [enter/return] to return to the main menu.";
			<STDIN>;
			$range=''; 
		}
	}
	#if selection is 5, ask file name for output, if they also want it put to the screen, if they want it as a .csv
	elsif($selection eq '5')
	{
		print "Enter the file name for output: ";
		chomp($outFile=<STDIN>);
		print "Would you still like the results output to the screen? (y/n) ";
		chomp($screenOut=<STDIN>);
		if($screenOut =~ m/[yY]/) { $outFile= "| tee $outFile"; }
		else{ $outFile= ">$outFile"; }
		print "Would you like to output this file as a .csv to be opened in a spreadsheet? (y/n) ";
		chomp($csv=<STDIN>);
		if($csv =~ m/[yY]/) { $outFile= "-d $outFile"; }
	}
	#if selection eq p, call and execute commands
	#creates then deletes a temp file located at /tmp/flsmactmp
	elsif($selection =~ m/[pP]/)
	{
		system("fls $fileSysType $offset -r -m $startLoc $file >/tmp/flsmactmp");
		system("mactime -b /tmp/flsmactmp $range" . $outFile);

		#cleanup temp file and exit
		system("rm -f /tmp/flsmactmp");
		exit;			
	}
	else { print "You entered an invalid selection, press [enter/return] to try again."; <STDIN>;	}

	$selection=mainMenu("fls " . $fileSysType . $offset . "-r -m " . $startLoc . $file . " >/tmp/flsmactmp", "mactime -b /tmp/flsmactmp $range" . $outFile);

}
